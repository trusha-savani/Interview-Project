import "./App.css";
import AdminLogin from "./Component/AdminLogin/AdminLogin";
import { BrowserRouter as Router, Switch, Route } from "react-router-dom";
import SideBar from "./Component/SideBar";
import Dashboard from "./Component/Pages/Dashboard";
import Category from "./Component/Pages/Category";
import Subcategory from "./Component/Pages/Subcategory";
import QustionAnswer from "./Component/Pages/QustionAnswer";
import Usernavbar from "./Component/Userpanel/Usernavbar";
import Home from "./Component/Userpanel/Home";
import About from "./Component/Userpanel/About";
import Question from "./Component/Userpanel/Question";
import Usercategory from "./Component/Userpanel/Usercategory";
import SubCategory from "./Component/Userpanel/SubCategory";
import Footer from "./Component/Userpanel/Footer";
import AdminSecure from "./Component/Pages/AdminSecure";



function App() {
  return (
    <div className="App">
      <Router>
        <Switch>
          <Route exact path="/">
            <Usernavbar />
            <Home />
            <About />
            <Usercategory />

            <Footer />
          </Route>

          <Route exact path="/about">
            <Usernavbar />
            <About />
            <Footer />
          </Route>


          <Route exact path="/usercategory">
            <Usernavbar />
            <Usercategory />
            <Footer />
          </Route>

          <Route exact path="/subcategory">
            <Usernavbar />
            <SubCategory />
            <Footer />
          </Route>

          <Route exact path="/question">
            <Usernavbar />
            <Question />
            <Footer />
          </Route>
          <Route exact path="/subcategory/:categoryId" >
          <Usernavbar />
            <SubCategory />
            <Footer />
          </Route  >
          
          <Route exact path="/Question/:subcatagoryID" >
          <Usernavbar />
          <Question />
            <Footer />
          </Route  >


          {/* <Route exact path="/Question/:subcatagoryID"  />
          <Route   /> */}

          <Route exact path="/admin/login">
            
            <AdminLogin />
          </Route>

          <Route exact path="/admin/dashboard">
            <AdminSecure>

            <Dashboard />
            </AdminSecure>
          </Route>

          <Route exact path="/admin/category">
          <AdminSecure>
            <Category />
            </AdminSecure>
          </Route>

          <Route exact path="/admin/subcategory">
          <AdminSecure>
            <Subcategory />
            </AdminSecure>
          </Route>

          <Route exact path="/admin/qustionanswer">
          <AdminSecure>
            <QustionAnswer />
            </AdminSecure>
          </Route>

          <Route exact path="/sidebar">
            <SideBar />
          </Route>

        </Switch>
      </Router>
    </div>
  );
}

export default App;
