import React from "react";
import Button from "@mui/material/Button";
import { styled } from "@mui/material/styles";
import Box from "@mui/material/Box";
import Paper from "@mui/material/Paper";
import Grid from "@mui/material/Grid";
import { Container, TextField, Typography } from "@mui/material";
import PlayCircleOutlineIcon from "@mui/icons-material/PlayCircleOutline";
import { Formik, Field, Form, ErrorMessage } from "formik";
import * as Yup from "yup";
import axios from "axios";
import Divider from "@mui/material/Divider";
import Stack from '@mui/material/Stack';
import FacebookIcon from '@mui/icons-material/Facebook';
import TwitterIcon from '@mui/icons-material/Twitter';
import GoogleIcon from '@mui/icons-material/Google';
import LinkedInIcon from '@mui/icons-material/LinkedIn';
import { useHistory } from "react-router-dom/cjs/react-router-dom.min";

const Admin_Login_Schema = Yup.object().shape({
  email: Yup.string().email("Invalid email").required("Required !"),
  password: Yup.string().required("Required !"),
});




const Item = styled(Paper)(({ theme }) => ({
  backgroundColor: theme.palette.mode === "dark" ? "#1A2027" : "#fff",
  ...theme.typography.body2,
  padding: theme.spacing(1),
  textAlign: "center",
  color: theme.palette.text.secondary,
}));

const Root = styled("div")(({ theme }) => ({
  width: "100%",
  ...theme.typography.body2,
  color: theme.palette.text.secondary,
  "& > :not(style) ~ :not(style)": {
    marginTop: theme.spacing(2),
  },
}));




const AdminLogin = () => {
  let history = useHistory()
  return (
   <Box className='back' height={{xl:'100vh',md:'auto',sm:'auto',xs:'auto'}} sx={{ position: 'relative', minHeight: '100vh', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
      <Box sx={{
                position: 'absolute',
                top: 0,
                left: 0,
                right: 0,
                bottom: 0,
                backgroundImage: 'url(https://img.freepik.com/free-photo/female-hand-typing-keyboard-laptop_1150-15742.jpg?t=st=1718163798~exp=1718167398~hmac=e609997fc31d489082cacef828159262609d9dc74a66224ea35d6823bb66e17c&w=740)',
                backgroundSize: 'cover',
                backgroundPosition: 'center',
                zIndex: 1,
                '::before': {
                    content: '""',
                    position: 'absolute',
                    top: 0,
                    left: 0,
                    right: 0,
                    bottom: 0,
                    backgroundColor: 'rgb(35 35 35 / 69%)',
                    zIndex: 2,
                }
            }}>
            </Box>
     
        <Grid container className="head" sx={{ zIndex: 3 }}>
        
          <Grid  item xs={12} sm={6} md={5} sx={{ mt:-2, display: 'flex', justifyContent: 'center' }}>
            <Item sx={{ backgroundColor: "#d092a1", height: "600px" }}>
              <Box sx={{ padding: "25px" }}>
                <Box sx={{ color: "white"}}>
                  <Typography
                    sx={{
                      fontSize: "30px",
                      fontStyle: "initial",
                      fontWeight: "700",
                    }}
                  >
                    LOGIN FORM
                  </Typography>
                </Box>
                <Box>
                  <Formik
                    initialValues={{
                      email: "",
                      password: "",
                    }}
                    validationSchema={Admin_Login_Schema}
                    onSubmit={async (values, action) => {
                      axios
                        .post(
                          "http://localhost:5500/admin/login",
                          values
                        )
                        .then((res) => {
                          console.log(res);
                          alert("successfully login");
                          localStorage.setItem("ADMINLOGIN", res.data.token)
                          history.push("/admin/dashboard")
                        })
                        .catch((err) => {
                          console.log(err);
                          alert("not valid");
                        });
                      action.resetForm();
                    }}
                  >
                    <Box sx={{ width: "100%", height: "600px" }}>
                      <Form>
                        <Box
                          sx={{
                            display: "flex",
                            flexDirection: "column",
                            textAlign: "start",
                            fontSize: "20px",
                            marginTop: "50px",
                          }}
                        >
                          <label htmlFor="email">
                            Email Address
                            <ErrorMessage
                              name="email"
                              component={"p"}
                              className="error"
                            />
                          </label>
                          <Field
                            as={TextField}
                            id="email"
                            name="email"
                            placeholder="jane@acme.com"
                            type="email"
                          />
                        </Box>
                        <Box
                          sx={{
                            display: "flex",
                            flexDirection: "column",
                            textAlign: "start",
                            fontSize: "20px",
                            marginTop: "20px",
                          }}
                        >
                          <label htmlFor="password">
                            Password
                            <ErrorMessage
                              name="password"
                              component={"p"}
                              className="error"
                            />
                          </label>
                          <Field
                            as={TextField}
                            id="password"
                            name="password"
                            placeholder="Password"
                          />
                        </Box>

                        <Box sx={{ width: "100%", marginTop: "40px" }}>
                          <Button
                            type="submit"
                            variant="contained"
                            sx={{ backgroundColor: "black" }}
                          >
                            SUBMIT
                          </Button>
                        </Box>
                        <Box sx={{ marginTop: "30px" }}>
                          <Root>
                            <Divider>Or width Social Profile</Divider>
                          </Root>
                        </Box>
                        <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'center', marginTop: '30px' }}>
                          <Stack
                            direction="row"
                            divider={
                              <Divider orientation="vertical" flexItem />
                            }
                            spacing={1}
                          >
                            <Box><FacebookIcon style={{ fontSize: '25px' }} /></Box>
                            <Box><TwitterIcon style={{ fontSize: '25px' }} /></Box>
                            <Box><GoogleIcon style={{ fontSize: '25px' }} /></Box>
                            <Box><LinkedInIcon style={{ fontSize: '25px' }} /></Box>
                          </Stack>
                        </Box>
                        <Box sx={{ marginTop: '30px' }}>
                          <a href="#">Already have an account? Login In </a>
                        </Box>
                      </Form>
                    </Box>
                  </Formik>
                </Box>
              </Box>
            </Item>
          </Grid>
        </Grid>
    
   </Box>
  );
};

export default AdminLogin;






