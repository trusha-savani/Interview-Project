
import React from 'react'
import SideBar from '../SideBar'
import Box from '@mui/material/Box';
import Typography from '@mui/material/Typography';
import Container from '@mui/material/Container'
import Button from '@mui/material/Button';
import { Formik, Field, Form, ErrorMessage } from 'formik';
import TextField from '@mui/material/TextField';
import axios from 'axios';
import { SearchTwoTone } from '@mui/icons-material';
import { useState } from 'react';
import useMediaQuery from '@mui/material/useMediaQuery';
import { useTheme } from '@mui/material/styles';
import FolderCopyIcon from '@mui/icons-material/FolderCopy';
import Dialog from '@mui/material/Dialog';
import DialogContent from '@mui/material/DialogContent';
import * as Yup from "yup";
import { useHistory } from 'react-router-dom/cjs/react-router-dom.min';
import { useEffect } from 'react';
import DialogActions from '@mui/material/DialogActions';
import TableContainer from '@mui/material/TableContainer';
import Table from '@mui/material/Table';
import TableBody from '@mui/material/TableBody';
import TableCell from '@mui/material/TableCell';
import EditIcon from '@mui/icons-material/Edit';
import TableHead from '@mui/material/TableHead';
import TableRow from '@mui/material/TableRow';
import Paper from '@mui/material/Paper';
import DeleteIcon from '@mui/icons-material/Delete';

const Qustion_Answer_Schema = Yup.object().shape({
    questions: Yup.string().required('IS REQUIRED'),
    answer: Yup.string().required('IS REQUIRED'),
    subcatagoryID: Yup.string().required('IS REQUIRED'),
    Description: Yup.string().required('IS REQUIRED'),
    metaTitle: Yup.string().required('IS REQUIRED'),
    slug: Yup.string().required('IS REQUIRED'),

});
function QustionAnswer() {
    let [Data, SetData] = useState([]);
    let [Initial, SetInitial] = useState({questions: '',answer:'',subcatagoryID:'',Description:'',metaTitle:'',slug:''});
    let [Edit, SetEdit] = useState(null);
    let [Search, SetSearch] = useState("")
    let [QustionAnswerData,SetQustionAnswerData]=useState([])
     const [open, setOpen] = React.useState(false);
    const theme = useTheme();
    const fullScreen = useMediaQuery(theme.breakpoints.down('md'));

    const handleClickOpen = () => {
        setOpen(true);
    };
    const handleClose = () => {
        setOpen(false);
    };
    let Get_Data = () => {
        axios.get("http://localhost:5500/questions/", {
            headers: {
                Authorization: localStorage.getItem("ADMINLOGIN")
            }
        })
            .then((res) => {
                console.log(res);
                SetData(res.data.data)
            })
            .catch((err) => {
                console.log(err);
            })
    }
    let QustionAnswer=()=>{
        axios.get("http://localhost:5500/subcatagory/", {
            headers: {
                Authorization: localStorage.getItem("ADMINLOGIN")
            }
        })
            .then((res) => {
                console.log(res);
                SetQustionAnswerData(res.data.data)
            })
            .catch((err) => {
                console.log(err);
            })
    }
    let HISTORY = useHistory();
     useEffect(() => {
       let ADMIN_TOKEN = localStorage.getItem("ADMINLOGIN");
        if (!ADMIN_TOKEN) {
            HISTORY.push('/admin/login')
        }
        Get_Data()
        QustionAnswer()
    }, [])

    let Delete_Handler = (_id) => {
        axios.delete("http://localhost:5500/questions//" + _id, {
            headers: {
                Authorization: localStorage.getItem("ADMINLOGIN")
            }
        })
            .then((res) => {
                console.log(res);
                Get_Data()
            })
            .catch((err) => {
                console.log(err);
            })
    }

    let Edit_Handler = (el, _id) => {
        handleClickOpen()
        SetInitial(el)
        SetEdit(_id)
    }
    return (
        <div style={{ marginTop: "65px" }}>
            <Box sx={{ display: 'flex' }}>
                <SideBar />
                <Box>
                    <Container maxWidth="xxl" >
                        <Box sx={{ marginTop: "20%", display: "flex", justifyContent: "space-between", alignItems: "center" }} >

                            <Box sx={{ display: "flex", alignItems: "center" }}>
                                <SearchTwoTone sx={{ marginRight: "20px", border: "2px solid", color: "#1976d2", p: 1, height: "55px", width: "55px", borderRadius: "5px" }} />
                                <TextField fullWidth label="SEARCH CATEGORIES HERE" sx={{ width: "400px" }} onChange={(e) => SetSearch(e.target.value)} />
                            </Box>

                            <Box>
                                <React.Fragment>
                                    <Button variant="contained" onClick={handleClickOpen} sx={{ marginRight: '10px' }}>
                                        <FolderCopyIcon sx={{ marginRight: "10px" }} /> ADD CATEGORIES
                                    </Button>
                                    <Dialog
                                        fullScreen={fullScreen}
                                        open={open}
                                        onClose={handleClose}
                                        aria-labelledby="responsive-dialog-title">
                                        <DialogContent>

                                            <Formik
                                                initialValues={Initial}
                                                enableReinitialize
                                                validationSchema={Qustion_Answer_Schema}
                                                onSubmit={async (values, action) => {
                                                    console.log(values);

                                                    if (Edit) {
                                                        axios.patch("http://localhost:5500/questions/" + Edit, values, {
                                                            headers: {
                                                                Authorization: localStorage.getItem("ADMINLOGIN")
                                                            }
                                                        })
                                                            .then((res) => {
                                                                console.log(res);
                                                                Get_Data();
                                                                handleClose();
                                                                SetEdit(null)
                                                            })
                                                            .catch((err) => {
                                                                console.log(err);
                                                            })
                                                    }
                                                    else {

                                                        axios.post("http://localhost:5500/questions/create", values, {
                                                            headers: {
                                                                Authorization: localStorage.getItem("ADMINLOGIN")
                                                            }
                                                        })
                                                            .then((res) => {
                                                                console.log(res);
                                                                Get_Data();
                                                                handleClose();
                                                            })
                                                            .catch((err) => {
                                                                console.log(err);
                                                            })
                                                    }
                                                    SetInitial({ questions: "", answer:'',subcatagoryID:'',Description:'',metaTitle:'',slug:'' })
                                                   action.resetForm()
                                                }}
                                            >
                                                <Form style={{ borderRadius: "0px 0px ", padding: "30px 30px" }}>
                                                    <Box sx={{ display: "flex", flexDirection: "column" }}>
                                                        <Box sx={{ display: "flex", justifyContent: "center", alignItems: "center", marginBottom: "10px" }}>
                                                            <FolderCopyIcon sx={{ marginRight: "5px" }} />
                                                            <Typography variant='h5' style={{ textAlign: "center", marginLeft: "5px" }}>  ADD SUB CATEGORIES </Typography>
                                                        </Box>
                                                        <Box>
                                                            <label htmlFor="questions" style={{ marginTop: "15px" }}>
                                                            <Typography variant="body1"> QUESTION <ErrorMessage name='questions' component={'span'} className='Error' /></Typography>
                                                            </label>
                                                            <Field as={TextField} id="questions" name="questions" placeholder="ENTER QUESTION HERE" type="questions" style={{ width: "400px", marginTop: "10px" }} />
                                                        </Box>
                                                        <Box>
                                                            <label htmlFor="answer" style={{ marginTop: "15px" }}>
                                                            <Typography variant="body1"> ANSWER <ErrorMessage name='answer' component={'span'} className='Error' /></Typography>
                                                        </label>
                                                        <Field as={TextField} id="answer" name="answer" placeholder="ENTER ANSWER HERE" type="answer" style={{ width: "400px", marginTop: "10px" }} />
                                                        </Box>
                                                        <Box>

                                                        <label htmlFor="subcatagoryID" style={{ marginTop: "15px" }}>
                                                            <Typography variant="body1"> SUB CATEGORY ID <ErrorMessage name='subcatagoryID' component={'span'} className='Error' /></Typography>
                                                        </label>
                                                        <Field as="select" id="subcatagoryID" name="subcatagoryID" placeholder="ENTER SUB CATEGORY ID HERE" type="subcatagoryID" style={{ width: "400px", marginTop: "10px",height:'50px',fontSize:'20px' }} >
                                                       

                                                        <option value={'none'} style={{fontSize:'20px'}} sx={{marginRight:'20px'}} >select</option>
                                                            {
                                                               QustionAnswerData.map((el,index)=>{
                                                                return(
                                                                    <option key={index} value={el._id} style={{fontSize:'18px'}}> {el.subCatagoryname} </option>
                                                                )
                                                            })
                                                            }
                                                        </Field>
                                                        </Box>
                                                        <Box>

                                                        <label htmlFor="Description" style={{ marginTop: "15px" }}>
                                                            <Typography variant="body1"> DESCRIPTON <ErrorMessage name='Description' component={'span'} className='Error' /></Typography>
                                                        </label>
                                                        <Field as={TextField} id="Description" name="Description" placeholder="ENTER QUESTION HERE" type="Description" style={{ width: "400px", marginTop: "10px" }} />
                                                        </Box>
                                                        <Box>

                                                        <label htmlFor="metaTitle" style={{ marginTop: "15px" }}>
                                                            <Typography variant="body1"> METATITLE <ErrorMessage name='metaTitle' component={'span'} className='Error' /></Typography>
                                                        </label>
                                                        <Field as={TextField} id="metaTitle" name="metaTitle" placeholder="ENTER QUESTION HERE" type="questions" style={{ width: "400px", marginTop: "10px" }} />
                                                        </Box>
                                                        <Box>

                                                        <label htmlFor="slug" style={{ marginTop: "15px" }}>
                                                            <Typography variant="body1"> QUESTION <ErrorMessage name='slug' component={'span'} className='Error' /></Typography>
                                                        </label>
                                                        <Field as={TextField} id="slug" name="slug" placeholder="ENTER QUESTION HERE" type="slug" style={{ width: "400px", marginTop: "10px" }} />
                                                        </Box>

                                                        <Box sx={{ marginTop: "25px", display: "flex", justifyContent: "space-between" }}>
                                                            <Button variant="contained" color="primary" style={{ width: "47%" }} type="reset">RESET</Button>
                                                            <Button variant="contained" color="primary" style={{ width: "47%" }} type="submit"> {Edit ? "UPDATE CATEGORY" : "ADD CATEGORIES"}</Button>
                                                        </Box>
                                                    </Box>
                                                </Form>
                                            </Formik>

                                        </DialogContent>
                                        <DialogActions>
                                            <Button onClick={handleClose}> CLOSE</Button>
                                        </DialogActions>
                                    </Dialog>
                                </React.Fragment>
                            </Box>
                        </Box>
                        <Box sx={{ marginTop: "50px",width:'800px' }}>
                            <TableContainer component={Paper}>
                                <Table sx={{ minWidth: 800 }} aria-label="simple table">
                                    <TableHead>
                                        <TableRow sx={{ backgroundColor: "#1976d2" }}>
                                            <TableCell sx={{ color: "white", border: '1px' }} align="center">INDEX</TableCell>
                                            <TableCell sx={{ color: "white" }} align="left">QUESTIONS</TableCell>
                                            <TableCell sx={{ color: "white" }} align="left">ANSWERS</TableCell>
                                            <TableCell sx={{ color: "white" }} align="center">SUB CATEGORIES</TableCell>
                                            <TableCell sx={{ color: "white" }} align="center">DESCRIPTION</TableCell>
                                            <TableCell sx={{ color: "white" }} align="center">METATITLE</TableCell>
                                            <TableCell sx={{ color: "white" }} align="center">SLUG</TableCell>
                                            <TableCell sx={{ color: "white" }} align="center">EDIT</TableCell>
                                            <TableCell sx={{ color: "white" }} align="center">DELETE</TableCell>
                                        </TableRow>
                                    </TableHead>
                                    <TableBody>
                                        {
                                            Data
                                            .filter((items) => {
                                                if (Search === "") {
                                                    return items
                                                }
                                                else if (items.catagoryName.toLowerCase().includes(Search.toLowerCase())) {
                                                    return items
                                                }
                                            })
                                                .map((el, index) => {
                                                    return (
                                                        <TableRow sx={{ '&:last-child td, &:last-child th': { border: 0 } }}>
                                                            <TableCell component="th" scope="row" align='center' >{index + 1}</TableCell>
                                                            <TableCell align="left">{el.questions}</TableCell>
                                                            <TableCell sx={{ textTransform: "uppercase" }} align="center">{el.answer}</TableCell>
                                                            <TableCell align="left">{el.Description}</TableCell>
                                                            <TableCell align="left">{el.metaTitle}</TableCell> 
                                                            <TableCell align="left">{el.slug}</TableCell>   
                                                            <TableCell align="center">{el.subcatagoryID.subCatagoryname}</TableCell>
                                                            <TableCell align="center">
                                                                <Button variant="contained" startIcon={<EditIcon />} onClick={() => { Edit_Handler(el, el._id) }}>
                                                                    EDIT
                                                                </Button>
                                                            </TableCell>
                                                            <TableCell align="center">
                                                                <Button variant="contained" startIcon={<DeleteIcon />} onClick={() => { Delete_Handler(el._id) }}>
                                                                    DELETE
                                                                </Button>
                                                            </TableCell>
                                                        </TableRow>
                                                    )
                                                })
                                        }
                                    </TableBody>
                                </Table>
                            </TableContainer>
                        </Box>
                    </Container>
                </Box>


            </Box>
        </div>
    )
}

export default QustionAnswer;