import React from "react";
import SideBar from "../SideBar";
import Box from "@mui/material/Box";
import Typography from "@mui/material/Typography";
import Container from "@mui/material/Container";
import Button from "@mui/material/Button";
import { Formik, Field, Form, ErrorMessage } from "formik";
import TextField from "@mui/material/TextField";
import axios from "axios";
import { SearchTwoTone } from "@mui/icons-material";
import { useState } from "react";
import useMediaQuery from "@mui/material/useMediaQuery";
import { useTheme } from "@mui/material/styles";
import FolderCopyIcon from "@mui/icons-material/FolderCopy";
import Dialog from "@mui/material/Dialog";
import DialogContent from "@mui/material/DialogContent";
import * as Yup from "yup";
import { useHistory } from "react-router-dom/cjs/react-router-dom.min";
import { useEffect } from "react";
import DialogActions from "@mui/material/DialogActions";
import TableContainer from "@mui/material/TableContainer";
import Table from "@mui/material/Table";
import TableBody from "@mui/material/TableBody";
import TableCell from "@mui/material/TableCell";
import EditIcon from "@mui/icons-material/Edit";
import TableHead from "@mui/material/TableHead";
import TableRow from "@mui/material/TableRow";
import Paper from "@mui/material/Paper";
import Switch from '@mui/material/Switch';
import DeleteIcon from "@mui/icons-material/Delete";
const Category_Schema = Yup.object().shape({
   catagoryName: Yup.string().required("IS REQUIRED"),
  categoryImage: Yup.mixed().required("IS REQUIRED"),
  alternamtiveImage: Yup.string().required("IS REQUIRED"),
  Description: Yup.string().required("IS REQUIRED"),
  metaTitle: Yup.string().required("IS REQUIRED"),
  slug: Yup.string().required("IS REQUIRED"),
});
function Category() {
  let [Data, SetData] = useState([]);
  let [Initial, SetInitial] = useState({catagoryName: "", categoryImage: "",alternamtiveImage: "",Description: "",metaTitle: "",slug: ""});
  let [Edit, SetEdit] = useState(null);
  let [Search, SetSearch] = useState("");
  const [open, setOpen] = React.useState(false);
  const theme = useTheme();
  const fullScreen = useMediaQuery(theme.breakpoints.down("md"));

  const handleClickOpen = () => {
    setOpen(true);
  };
  const handleClose = () => {
    setOpen(false);
  };
  let GetData = () => {
    axios.get("http://localhost:5500/catagory/", {
        headers: {
          Authorization: localStorage.getItem("ADMINLOGIN"),
        },
      })
      .then((res) => {
        console.log(res);
        SetData(res.data.data);
      })
      .catch((err) => {
        console.log(err);
      });
  };
  let HISTORY = useHistory();

  useEffect(() => {
    let ADMIN_TOKEN = localStorage.getItem("ADMINLOGIN");
     if (!ADMIN_TOKEN) {
        HISTORY.push("/admin/login");
    }
    GetData();
    }, []);

  let DeleteHandler = (_id) => {
    console.log("Deleting ID:", _id); 
    axios.delete("http://localhost:5500/catagory/" + _id, {
        headers: {
          Authorization: localStorage.getItem("ADMINLOGIN"),
        },
      })
      .then((res) => {
        console.log(res);
        
        GetData();
      
      })
      .catch((err) => {
        console.log(err);
      });
  };

  let EditHandler = (el, _id) => {
    handleClickOpen();
    SetInitial({
      catagoryName: el.catagoryName,
      categoryImage: el.categoryImage,  
      alternamtiveImage: el.alternamtiveImage,
      Description: el.Description,
      metaTitle: el.metaTitle,
      slug: el.slug,
    });
    SetEdit(_id);
  };

let HendlerToggle=(_id,NewStatus)=>{

  axios.patch("http://localhost:5500/catagory/" +_id,{status:NewStatus},
    {
      headers: {
        Authorization:
          localStorage.getItem("ADMINLOGIN"),
      },
    }
  )
  .then((res) => {
    console.log(res);
    GetData();
   
  })
  .catch((err) => {
    console.log(err);
  });
}
  return (
    <div style={{ marginTop: "65px" }}>
      <Box sx={{ display: "flex" }}>
        <SideBar />
        <Box>
          <Container maxWidth="xxl">
            <Box sx={{ marginTop: "20%",display: "flex", justifyContent: "space-between", alignItems: "center"}}>
              <Box sx={{ display: "flex", alignItems: "center" }}>
                <SearchTwoTone sx={{ marginRight: "20px",border: "2px solid",color: "#1976d2",p: 1,height: "55px",width: "55px",borderRadius: "5px"}}/>
                <TextField fullWidth label="SEARCH...." sx={{ width: "400px" }} onChange={(e) => SetSearch(e.target.value)} />
              </Box>
              <Box>
                <React.Fragment>
                  <Button variant="contained" onClick={handleClickOpen}sx={{ marginRight: "10px" }}>
                     <FolderCopyIcon sx={{ marginRight: "10px" }} /> ADD CATEGORIES
                  </Button>
                  <Dialog
                    fullScreen={fullScreen}
                    open={open}
                    onClose={handleClose}
                    aria-labelledby="responsive-dialog-title"
                  >
                    
                    <DialogContent>
                      <Formik
                        initialValues={Initial}
                        enableReinitialize
                        validationSchema={Category_Schema}
                        onSubmit={async (values, action) => {
                          console.log(values);
                            let FORM_DATA = new FormData();
                          FORM_DATA.append("catagoryName", values.catagoryName);

                            for (let i = 0;i < values.categoryImage.length;i++) {
                              FORM_DATA.append("categoryImage",values.categoryImage[i]);
                            }
                          FORM_DATA.append("alternamtiveImage", values.alternamtiveImage);
                          FORM_DATA.append("Description", values.Description);
                          FORM_DATA.append("metaTitle", values.metaTitle);
                          FORM_DATA.append("slug", values.slug);

                          if (Edit) {
                            axios.patch("http://localhost:5500/catagory/" + Edit,FORM_DATA,
                                {
                                  headers: {
                                    Authorization:
                                      localStorage.getItem("ADMINLOGIN"),
                                      "Content-Type": "multipart/form-data"
                                  },
                                }
                              )
                              .then((res) => {
                                console.log(res);
                                GetData();
                                handleClose();
                                SetEdit(null);
                              })
                              .catch((err) => {
                                console.log(err);
                              });
                          } else {
                            axios.post("http://localhost:5500/catagory/create",FORM_DATA,
                                {
                                  headers: {
                                    Authorization:
                                      localStorage.getItem("ADMINLOGIN"),
                                      "Content-Type": "multipart/form-data"
                                  },
                                }
                              )
                              .then((res) => {
                                console.log(res);
                                GetData();
                                handleClose();
                              })
                              .catch((err) => {
                                console.log(err);
                              });
                          }
                          SetInitial({ catagoryName: "",categoryImage: "", alternamtiveImage: "", Description: "", metaTitle: "", slug: ""});
                          action.resetForm();
                        }}
                      >
                 {(props) => (
                          <Form style={{ borderRadius: "0px 0px ", padding: "30px 30px" }}>
                            <Box sx={{ display: "flex", flexDirection: "column" }}>
                              <Box sx={{ display: "flex", justifyContent: "center",alignItems: "center",marginBottom: "10px" }}>
                                <FolderCopyIcon sx={{ marginRight: "5px" }} />
                                <Typography variant="h5" style={{ textAlign: "center", marginLeft: "5px", }}
                                >
                                  ADD CATEGORIES
                                </Typography>
                              </Box>
                              <Box>
                                <label htmlFor="catagoryName" style={{ marginTop: "15px" }}>
                                <Typography variant="body1"> CATEGORY NAME<ErrorMessage name="catagoryName" component={"span"} className="Error" /></Typography>
                                </label>
                                <Field as={TextField} id="catagoryName" name="catagoryName" placeholder="ENTER CATEGORY NAME HERE" type="catagoryName" style={{ width: "400px" }} />
                              </Box>
                              <Box>
                                <label htmlFor="categoryImage" style={{ marginTop: "15px" }} >
                                  <Typography variant="body1"> CATEGORY IMAGE<ErrorMessage name="categoryImage" component={"span"} className="Error" /> </Typography>
                                </label>
                                <input onChange={(e) => props.setFieldValue( "categoryImage", e.target.files ) } style={{ width: "400px" }} className="mb-2" id="categoryImage" name="categoryImage" placeholder=" ENTER AT LIST categoryImage" type="file" multiple/>

                                {/* <Field as={TextField} id="categoryImage" name="catacategoryImagegoryName" placeholder="ENTER CATEGORY CATEGORY IMAGE" type="catagoryName" style={{ width: "400px" }} /> */}
                              </Box>
                              <Box sx={{ marginTop: "10px" }}>
                                <label htmlFor="alternamtiveImage">
                                  <Typography variant="body1"> ALTERNATIVE IMAGE<ErrorMessage name="alternamtiveImage" component={"span"} className="Error" /> </Typography>
                                </label>
                                <Field as={TextField} id="alternamtiveImage" name="alternamtiveImage" placeholder="ENTER CATEGORY ALTERNATIVE IMAGE" style={{ width: "400px" }} />
                              </Box>
                              <Box sx={{ marginTop: "10px" }}>
                                <label htmlFor="Description">
                                  <Typography variant="body1"> DESCRIPTION <ErrorMessage name="Description" component={"span"} className="Error" />
                                  </Typography>
                                </label>
                                <Field as={TextField} id="Description" name="Description" placeholder="ENTER CATEGORY DESCRIPTION"  style={{ width: "400px" }} />
                              </Box>
                              <Box sx={{ marginTop: "10px" }}>
                                <label htmlFor="metaTitle">
                                  <Typography variant="body1"> METATITLE <ErrorMessage name="metaTitle" component={"span"} className="Error" />
                                  </Typography>
                                </label>
                                <Field as={TextField} id="metaTitle" name="metaTitle" placeholder="ENTER CATEGORY METATITLE"   style={{ width: "400px" }} />
                              </Box>
                              <Box sx={{ marginTop: "10px" }}>
                                <label htmlFor="slug">
                                   <Typography variant="body1"> SLUG<ErrorMessage name="slug" component={"span"} className="Error"/>
                                  </Typography>
                                </label>
                                <Field as={TextField} id="slug" name="slug" placeholder="ENTER CATEGORY SLUG"  style={{ width: "400px" }} />
                              </Box>
                              <Box sx={{ marginTop: "25px", display: "flex", justifyContent: "space-between",}}>
                                <Button variant="contained" color="primary" sx={{ width: "47%" }} type="reset">
                                  RESET
                                </Button>
                                <Button variant="contained" color="primary" style={{ width: "47%" }} type="submit">
                                  {Edit ? "UPDATE CATEGORY" : "ADD CATEGORIES"}
                                </Button>
                              </Box>
                            </Box>
                          </Form>
                        )}
                      </Formik>
                    </DialogContent>
                    <DialogActions>
                      <Button onClick={handleClose}> CLOSE</Button>
                    </DialogActions>
                  </Dialog>
                </React.Fragment>
              </Box>
            </Box>
            <Box sx={{ marginTop: "50px",width:'900PX' }}>
              <TableContainer component={Paper}>
                <Table sx={{ minWidth: 800 }} aria-label="simple table">
                  <TableHead>
                    <TableRow sx={{ backgroundColor: "#1976d2" }}>
                      <TableCell sx={{ color: "white" }} align="center" >INDEX</TableCell>
                      <TableCell sx={{ color: "white" }} align="right"> CATEGORIES</TableCell>
                      <TableCell sx={{ color: "white" }} align="center">STATUS</TableCell>
                      <TableCell sx={{ color: "white" }} align="center"> CATEGORY IMAGE </TableCell>
                      <TableCell sx={{ color: "white" }} align="center"> DESCRIPTION </TableCell>
                      <TableCell sx={{ color: "white" }} align="center"> METATITLE</TableCell>
                      <TableCell sx={{ color: "white" }} align="center"> SLUG </TableCell>
                      <TableCell sx={{ color: "white" }} align="center">
                        EDIT
                      </TableCell>
                      <TableCell sx={{ color: "white" }} align="center">
                        DELETE
                      </TableCell>
                    </TableRow>
                  </TableHead>
                  <TableBody>
                    {Data.filter((items) => {
                      if (Search === "") {
                        return items;
                      } else if (
                        items.catagoryName
                          .toLowerCase()
                          .includes(Search.toLowerCase())
                      ) {
                        return items;
                      }
                    }).map((el, index) => {
                      return (
                        <TableRow
                          sx={{
                            "&:last-child td, &:last-child th": { border: 0 },
                          }}
                        >
                          <TableCell component="th" scope="row" align="center">
                            {index + 1}
                          </TableCell>
                          <TableCell align="right">{el.catagoryName}</TableCell>
                          <TableCell
                            sx={{ textTransform: "uppercase" }}
                            align="center"
                          >
                            {el.status}
                            <Switch  defaultChecked={el.status ==="on"? true : false}  
                            onChange={(e)=>HendlerToggle(el._id,e.target.checked ? "on":"off")}  />
                            
                          </TableCell>
                          <TableCell align="right">
                                         
   
                        
                            <img src={`http://localhost:5500/images/category/${el.categoryImage}`} alt={el.alternamtiveImage} style={{width:'100px',height:'100px'}} />
                          </TableCell>
                          <TableCell align="center">{el.Description}</TableCell>
                          <TableCell align="center">{el.metaTitle}</TableCell>
                          <TableCell align="center">{el.slug}</TableCell>
                          <TableCell align="center">
                            <Button variant="contained" startIcon={<EditIcon />} onClick={() => { EditHandler(el, el._id);}}>
                              EDIT
                            </Button>
                          </TableCell>
                          <TableCell align="center">
                            <Button variant="contained" startIcon={<DeleteIcon />} onClick={() => {DeleteHandler(el._id);}}>
                              DELETE
                            </Button>
                          </TableCell>
                        </TableRow>
                      );
                    })}
                  </TableBody>
                </Table>
              </TableContainer>
            </Box>
          </Container>
        </Box>
      </Box>
    </div>
  );
}

export default Category;
