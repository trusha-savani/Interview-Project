import React, { useEffect, useState } from "react";
import SideBar from "../SideBar";
import Box from "@mui/material/Box";
import Typography from "@mui/material/Typography";
import Breadcrumbs from "@mui/material/Breadcrumbs";
import Link from "@mui/material/Link";
import { useHistory } from "react-router-dom/cjs/react-router-dom.min";
import Grid from "@mui/material/Grid";
import { styled } from "@mui/material/styles";
import Paper from "@mui/material/Paper";
import HelpCenterIcon from "@mui/icons-material/HelpCenter";
import CategoryIcon from "@mui/icons-material/Category";
import { Container, Divider } from "@mui/material";
import axios from "axios";
import CountUp from "react-countup";
import CardContent from "@mui/material/CardContent";
import Card from "@mui/material/Card";
import { CardActionArea } from "@mui/material";
import FolderCopyIcon from "@mui/icons-material/FolderCopy";
function Dashboard() {
  let history = useHistory();
  let [CategoryCount, SetCategoryCount] = useState([]);
  let [SubCategoryCount, SetSubCategoryCount] = useState([]);
  let [QustionAnswerCount, SetQustionAnswerCount] = useState([]);

  let Category = () => {
    axios.get("http://localhost:5500/catagory/", {
        headers: {
          Authorization: localStorage.getItem("ADMINLOGIN"),
        },
      })
      .then((res) => {
        console.log(res);
        SetCategoryCount(res.data.data);
      })
      .catch((err) => {
        console.log(err);
      });
  };

  let SubCategory = () => {
    axios.get("http://localhost:5500/subcatagory/", {
        headers: {
          Authorization: localStorage.getItem("ADMINLOGIN"),
        },
      })
      .then((res) => {
        console.log(res);
        SetSubCategoryCount(res.data.data);
      })
      .catch((err) => {
        console.log(err);
      });
  };

  let QustionAnswer = () => {
    axios.get("http://localhost:5500/questions/", {
        headers: {
          Authorization: localStorage.getItem("ADMINLOGIN"),
        },
      })
      .then((res) => {
        console.log(res);
        SetQustionAnswerCount(res.data.data);
      })
      .catch((err) => {
        console.log(err);
      });
  };

  useEffect(() => {
    let Token = localStorage.getItem("ADMINLOGIN");
    if (!Token) {
      history.push("/admin/login");
    }
    Category();
    SubCategory();
    QustionAnswer();
  });
  const Item = styled(Paper)(({ theme }) => ({
    backgroundColor: theme.palette.mode === "dark" ? "#1A2027" : "#fff",
    ...theme.typography.body2,
    padding: theme.spacing(1),
    textAlign: "center",
    color: theme.palette.text.secondary,
  }));
  return (
    <div>
      <Box sx={{ display: "flex" }}>
        <SideBar />
        <Box component="main" sx={{ flexGrow: 1, marginTop: "6%", marginLeft: "10px" }}>
        <Box>
          <Container>

          
            <Grid container spacing={5} sx={{ justifyContent: "center", marginTop: "20px" }}>
              <Grid item xs={4}>
                <Box sx={{ marginTop: "50px" }}>
                  <Card sx={{ maxWidth: 350,backgroundColor: "#1976d2",margin: "30px",opacity: "0.9"}}>
                    <CardActionArea>
                      <CardContent>
                        <Typography variant="body1" color="white">
                            <CategoryIcon sx={{ fontSize: "25px" }} />
                        </Typography>

                        <Typography color="white" gutterBottom variant="h6" component="div">
                          Category
                        </Typography>
                        <Divider sx={{ backgroundColor: "white" }} />
                        <Typography sx={{ textAlign: "center", fontSize: "30px" }} color="white">
                             <CountUp start={0} duration={5} end={CategoryCount.length}/>
                        </Typography>
                      </CardContent>
                    </CardActionArea>
                  </Card>
                </Box>
              </Grid>
              <Grid item xs={4}>
                <Box sx={{ marginTop: "50px" }}>
                  <Card sx={{ maxWidth: 350,backgroundColor: "#1976d2",margin: "30px",opacity: "0.9"}}>
                    <CardActionArea>
                      <CardContent>
                        <Typography variant="body1" color="white">
                         <FolderCopyIcon sx={{ fontSize: "25px" }} />
                        </Typography>

                        <Typography color="white" gutterBottom variant="h6" component="div" >
                          Sub Category
                        </Typography>
                        <Divider sx={{ backgroundColor: "white" }} />
                        <Typography sx={{ textAlign: "center", fontSize: "30px" }} color="white" >
                          <CountUp start={0} duration={5} end={SubCategoryCount.length} />
                        </Typography>
                      </CardContent>
                    </CardActionArea>
                  </Card>
                </Box>
              </Grid>
              <Grid item xs={4}>
                <Box sx={{ marginTop: "50px" }}>
                  <Card sx={{ maxWidth: 350,backgroundColor: "#1976d2",margin: "30px",opacity: "0.9"}}>
                    <CardActionArea>
                      <CardContent>
                        <Typography variant="body1" color="white">
                           <HelpCenterIcon sx={{ fontSize: "25px" }} />
                        </Typography>

                        <Typography color="white" gutterBottom variant="h6" component="div" >
                          Qustion Answer
                        </Typography>
                        <Divider sx={{ backgroundColor: "white" }} />
                        <Typography sx={{ textAlign: "center", fontSize: "30px" }} color="white">
                          <CountUp start={0} duration={5} end={QustionAnswerCount.length}/>
                        </Typography>
                      </CardContent>
                    </CardActionArea>
                  </Card>
                </Box>
              </Grid>
            </Grid>
            </Container>
          </Box>
        </Box>
      </Box>
    </div>
  );
}

export default Dashboard;
