import React from 'react'
import { useHistory } from "react-router-dom/cjs/react-router-dom.min";
import { useEffect } from "react";
import { useState } from 'react';

function AdminSecure(props) {
  let [token,settoken]=useState('')
  let history = useHistory();

  useEffect(() => {
    let ADMIN_TOKEN = localStorage.getItem("ADMINLOGIN");
     if (!ADMIN_TOKEN) {
      history.push("/admin/login");
    }
    else{
      setTimeout(()=>{
        settoken(ADMIN_TOKEN)
      },2000)
    }
}, []);

if(!token){
  return <div className='loderbox'><span class="loader"></span></div>
}

  return (
    <>
      {props.children}
    </>
  )
}

export default AdminSecure
