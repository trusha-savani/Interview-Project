import * as React from 'react';
import { styled, useTheme } from '@mui/material/styles';
import Box from '@mui/material/Box';
import MuiDrawer from '@mui/material/Drawer';
import MuiAppBar from '@mui/material/AppBar';
import List from '@mui/material/List';
import CssBaseline from '@mui/material/CssBaseline';
import Toolbar from '@mui/material/Toolbar';
import Divider from '@mui/material/Divider';
import IconButton from '@mui/material/IconButton';
import MenuIcon from '@mui/icons-material/Menu';
import ChevronLeftIcon from '@mui/icons-material/ChevronLeft';
import ChevronRightIcon from '@mui/icons-material/ChevronRight';
import ListItem from '@mui/material/ListItem';
import ListItemButton from '@mui/material/ListItemButton';
import ListItemIcon from '@mui/material/ListItemIcon';
import ListItemText from '@mui/material/ListItemText';
import DashboardIcon from '@mui/icons-material/Dashboard';
import Typography from '@mui/material/Typography';
import CategoryIcon from '@mui/icons-material/Category';
import SourceIcon from '@mui/icons-material/Source';
import HelpCenterIcon from '@mui/icons-material/HelpCenter';
import ForwardIcon from '@mui/icons-material/Forward';
import { Button } from '@mui/material';
import { useHistory } from 'react-router-dom/cjs/react-router-dom.min';
const drawerWidth = 240;


const openedMixin = (theme) => ({
  width: drawerWidth,
  transition: theme.transitions.create('width', {
    easing: theme.transitions.easing.sharp,
    duration: theme.transitions.duration.enteringScreen,
  }),
  overflowX: 'hidden',
});

const closedMixin = (theme) => ({
  transition: theme.transitions.create('width', {
    easing: theme.transitions.easing.sharp,
    duration: theme.transitions.duration.leavingScreen,
  }),
  overflowX: 'hidden',
  width: `calc(${theme.spacing(7)} + 1px)`,
  [theme.breakpoints.up('sm')]: {
    width: `calc(${theme.spacing(8)} + 1px)`,
  },
});



const AppBar = styled(MuiAppBar, {
  shouldForwardProp: (prop) => prop !== 'open',
})(({ theme, open }) => ({
  zIndex: theme.zIndex.drawer + 1,
  transition: theme.transitions.create(['width', 'margin'], {
    easing: theme.transitions.easing.sharp,
    duration: theme.transitions.duration.leavingScreen,
  }),
  ...(open && {
    marginLeft: drawerWidth,
    width: `calc(100% - ${drawerWidth}px)`,
    transition: theme.transitions.create(['width', 'margin'], {
      easing: theme.transitions.easing.sharp,
      duration: theme.transitions.duration.enteringScreen,
    }),
  }),
}));



const Drawer = styled(MuiDrawer, { shouldForwardProp: (prop) => prop !== 'open' })(
  ({ theme, open }) => ({
    width: drawerWidth,
    flexShrink: 0,
    whiteSpace: 'nowrap',
    boxSizing: 'border-box',
    ...(open && {
      ...openedMixin(theme),
      '& .MuiDrawer-paper': openedMixin(theme),
    }),
    ...(!open && {
      ...closedMixin(theme),
      '& .MuiDrawer-paper': closedMixin(theme),
    }),
  }),
);

export default function SideBar() {
  const theme = useTheme();
  const [open, setOpen] = React.useState(true);
  const handleDrawerOpen = () => {
    setOpen(true);
  };
  const handleDrawerClose = () => {
    setOpen(false);
  };

let history = useHistory() ;
let Logout=()=>{
  localStorage.removeItem("ADMINLOGIN")
  history.push("/admin/login")
}

  return (

    <Box sx={{ display: 'flex', justifyContent: 'space-between' }}>

      <CssBaseline />
      <AppBar position="fixed" open={open} sx={{width:'100%'}}>

        <Toolbar sx={{ display: 'flex', justifyContent: 'space-between' }}>

          <IconButton
            color="inherit"
            aria-label="open drawer"
            onClick={handleDrawerOpen}
            edge="start"
            sx={{
              marginRight: 5,
              ...(open && { display: 'none' }),
            }}
          >

            <MenuIcon />
          </IconButton>

         
            <Box>
            <Typography variant="h6"  component="div">INTERVIEW</Typography>

            </Box>

            <Box sx={{ml:'auto'}}>
              <Button variant="contained" onClick={()=>Logout()} endIcon={<ForwardIcon />}>log out</Button>
            </Box>

        

        </Toolbar>

      </AppBar>

      <Drawer variant="permanent" open={open}>
        <Box sx={{ display: 'flex', alignItems: "center", justifyContent: 'center', height: '60px', fontStyle: 'italic' }}>
          <img
            src="https://bootstrapmade.com/demo/templates/NiceAdmin/assets/img/logo.png"
            alt="NiceAdminlogo"
            width="25px"
            height="25px"

          />
          <Typography sx={{ fontSize: '25px', marginLeft: '5px' }} md={{display:'flex'}} sm={{display:'flex'}} >INTERVIEW</Typography>
          <IconButton onClick={handleDrawerClose}>
            {theme.direction === 'rtl' ? <ChevronRightIcon  /> : <ChevronLeftIcon />}
          </IconButton>
        </Box>

       
        <Divider />


        <Divider />
        <List>

          <ListItem disablePadding sx={{ display: 'block' }} onClick={() => { history.push("/admin/dashboard") }}>
            <ListItemButton
              sx={{
                minHeight: 48,
                justifyContent: open ? 'initial' : 'center',
                px: 2.5,
              }}
            >
              <ListItemIcon
                sx={{
                  minWidth: 0,
                  mr: open ? 1 : 'auto',
                  justifyContent: 'center',
                }}
              >
                <DashboardIcon style={{color:'#1976d2'}} />
              </ListItemIcon>
              <ListItemText primary='Dashboard' sx={{ opacity: open ? 1 : 0 }} />
            </ListItemButton>
          </ListItem>

        </List>
        <Divider />
        <List>

          <ListItem disablePadding sx={{ display: 'block' }} onClick={() => { history.push("/admin/category") }} >
            <ListItemButton
              sx={{
                minHeight: 48,
                justifyContent: open ? 'initial' : 'center',
                px: 2.5,
              }}
            >
              <ListItemIcon
                sx={{
                  minWidth: 0,
                  mr: open ? 1 : 'auto',
                  justifyContent: 'center',
                }}
              >
                <CategoryIcon  style={{color:'#1976d2'}} />
              </ListItemIcon>
              <ListItemText primary='category' sx={{ opacity: open ? 1 : 0 }} />
            </ListItemButton>
          </ListItem>

        </List>
        <Divider />
        <List>

          <ListItem disablePadding sx={{ display: 'block' }} onClick={() => { history.push("/admin/subcategory") }}   >
            <ListItemButton
              sx={{
                minHeight: 48,
                justifyContent: open ? 'initial' : 'center',
                px: 2.5,
              }}
            >
              <ListItemIcon
                sx={{
                  minWidth: 0,
                  mr: open ? 1 : 'auto',
                  justifyContent: 'center',
                }}
              >
                <SourceIcon  style={{color:'#1976d2'}} />
              </ListItemIcon>
              <ListItemText primary='Subcategory' sx={{ opacity: open ? 1 : 0 }} />
            </ListItemButton>
          </ListItem>

        </List>
        <Divider />
        <List>

          <ListItem disablePadding sx={{ display: 'block' }} onClick={() => { history.push("/admin/qustionanswer") }}  >
            <ListItemButton
              sx={{
                minHeight: 48,
                justifyContent: open ? 'initial' : 'center',
                px: 2.5,
              }}
            >
              <ListItemIcon
                sx={{
                  minWidth: 0,
                  mr: open ? 1 : 'auto',
                  justifyContent: 'center',
                }}
              >
                <HelpCenterIcon  style={{color:'#1976d2'}} />
              </ListItemIcon>
              <ListItemText primary='Qustion Answer' sx={{ opacity: open ? 1 : 0 }} />
            </ListItemButton>
          </ListItem>

        </List>
      </Drawer>

    </Box>
  );
}