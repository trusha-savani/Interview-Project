import React from "react";
import { Box, Divider } from "@mui/material";
import Container from "@mui/material/Container";
import AutoStoriesIcon from "@mui/icons-material/AutoStories";
import Typography from "@mui/material/Typography";
import { useState } from "react";
import axios from "axios";
import { useEffect } from "react";
import Card from "@mui/material/Card";
import Grid from '@mui/material/Grid';
import CardContent from "@mui/material/CardContent";
import Button from "@mui/material/Button";
import { SearchTwoTone } from "@mui/icons-material";
import TextField from "@mui/material/TextField";
import FolderCopyIcon from "@mui/icons-material/FolderCopy";
import AOS from 'aos';
import 'aos/dist/aos.css';
import { useHistory } from "react-router-dom/cjs/react-router-dom.min";
import CircularProgress from '@mui/material/CircularProgress';
import CardMedia from '@mui/material/CardMedia';
const style = {
  position: 'absolute',
  top: '50%',
  left: '50%',
  transform: 'translate(-50%, -50%)',
  width: 400,
  bgcolor: 'background.paper',
  border: '2px solid #000',
  boxShadow: 24,
  p: 4,
};
function Usercategory() {
  let [Carddata, Setcarddata] = useState([]);
  let [Search, SetSearch] = useState("");
  const [open, setOpen] = React.useState(false);
  let [Loading,SetLoading]=useState(true);
  // const [openModal, setOpenModal] = useState(false);


  let HISTORY = useHistory();
  const handleClickOpenModal =  (category) => {
    console.log(category._id);
    HISTORY.push(`/subcategory/${category._id}`);
  };

  
  // const handleCloseModal = () => {
  //   setOpenModal(false);
  // };


  const handleClickOpen = () => {
    setOpen(true);
  };

  let Category_Data = () => {
    axios
      .get("http://localhost:5500/catagory/", {
        headers: {
          Authorization: localStorage.getItem("ADMINLOGIN"),
          "Content-Type": "multipart/form-data"
        },
      })
      .then((res) => {
        console.log(res);
        Setcarddata(res.data.data);
        SetLoading(false)
      })
      .catch((err) => {
        console.log(err);
        SetLoading(false)
      });
  };

useEffect(() => {

  Category_Data()
  
}, []);
 
AOS.init();
  AOS.init();
  return (
    <div>
      <Box sx={{ marginBottom: "50px" }}>
        {/* {Loading?(
          <Box sx={{ display: 'flex',alignItems:'center',justifyContent:'center',height:'100vh' }}>
          <CircularProgress />
        </Box>
        ):( */}
          <Container>
        
          <Box sx={{display: "flex",
              justifyContent: "center",
              alignItems: "center",
              margin: "50px 0px"
              
            }}
            data-aos="fade-up"
          >
            <AutoStoriesIcon sx={{ fontSize: "50px", mr: 2 }} />
            <Typography variant="h4" color="#1976D2">
              Category
            </Typography>
            <AutoStoriesIcon
              sx={{ fontSize: "50px", mr: 2, marginLeft: "20px" }}
            />
          </Box>
          <Box  sx={{ display: "flex", alignItems: "center",justifyContent:'center' }}data-aos="fade-up">
                <SearchTwoTone
                  sx={{
                    marginRight: "20px",
                    border: "2px solid",
                    color: "#1976D2",
                    p: 1,
                    height: "35px",
                    width: "35px",
                    borderRadius: "5px",
                  }}
                />
                <TextField
                  fullWidth
                  label="SEARCH...."
                  sx={{ width: "400px" }}
                  onChange={(e) => SetSearch(e.target.value)}
                />
                <Button
                    variant="contained"
                    onClick={handleClickOpen}
                    sx={{ marginLeft: "10px",background:'#1976D2' }}
                    sm={{display:"none"}}
                  >
                    <FolderCopyIcon sx={{ marginRight: "10px" }} display={{sm:"none"}}/> Sreach 
                    CATEGORIES
                  </Button>
              </Box>
             


          <Grid container spacing={2} sx={{marginBottom:'20px'}} >
          {
          // Carddata.filter((items) => {
          //             if (Search === "") {
          //               return items;
          //             } else if (items.catagoryName.toLowerCase().includes(Search.toLowerCase())
          //             ) {
          //               return items;
          //             }
          //           })
          Carddata.filter((items)=>{
            if(items.status === "on"){
              return items == ""|| items.catagoryName.toLowerCase().includes(Search.toLowerCase())
            }
            
          }).map((el, index) => (
               

             
              <Grid item xl={4} md={4} sm={6} xs={12} key={index} sx={{marginTop:'40px'}} data-aos="fade-up"  >
              
                <Card 
                  sx={{ minWidth: 275,background:'#fff',boxShadow:'10px 0px 10px #D5D8DC ' }}
                  data-aos="fade-up"  onClick={() => handleClickOpenModal(el)}
                >
                  {/* <Box>
                  <img src={`http://localhost:5500/images/category/${el.categoryImage}`} alt={el.alternamtiveImage} style={{width:'100%',height:'200px'}} />
                  </Box> */}
                  <CardMedia
                     sx={{ height: 200 }}
                     component="img"
                     image={`http://localhost:5500/images/category/${el.categoryImage}`}
                     title="green iguana"
                     alt="{el.alternamtiveImage} "
                     />
                
                  <CardContent>
                    {/* <Typography
                      sx={{ fontSize: 14,textAlign:'center',color:'white' }}
                      color="text.secondary"
                      gutterBottom
                    >
                    </Typography> */}
                    <Box sx={{display:'flex',justifyContent:'start',alignItems:'center' }}>

                     <FolderCopyIcon sx={{color:'#1976D2',marginRight:'10px'}} />
                    <Typography variant="h5"   component="div" sx={{textAlign:'start',color:'#1976D2'}}  >{el.catagoryName}</Typography>
                    </Box>
                    <Divider sx={{backgroundColor:'black',mt:'5px'}} />
                    <Typography variant="h6" component="div" sx={{color:'grey',textAlign:'start'}}>{el.Description}</Typography>
                    <Typography variant="h5" component="div" sx={{color:'grey',textAlign:'start'}}>{el.metaTitle}</Typography>
                    <Typography variant="h5" component="div" sx={{color:'grey',textAlign:'start'}}>{el.slug}</Typography>
                  </CardContent>
                </Card>
              </Grid>
              
          ))}
          </Grid>
        </Container>
        {/* )} */}
        
      </Box>
      
    </div>
  );
}

export default Usercategory;
