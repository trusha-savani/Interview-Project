import * as React from 'react';
import { styled } from '@mui/material/styles';
import ArrowForwardIosSharpIcon from '@mui/icons-material/ArrowForwardIosSharp';
import MuiAccordion from '@mui/material/Accordion';
import MuiAccordionSummary from '@mui/material/AccordionSummary';
import MuiAccordionDetails from '@mui/material/AccordionDetails';
import Typography from '@mui/material/Typography';
import { useState } from 'react';
import { useEffect } from 'react';
import axios from 'axios';
import { Box } from '@mui/material';
import AutoStoriesIcon from '@mui/icons-material/AutoStories';
import Container from '@mui/material/Container';
import { SearchTwoTone } from "@mui/icons-material";
import TextField from "@mui/material/TextField";
import Button from "@mui/material/Button";
import { useHistory } from "react-router-dom/cjs/react-router-dom.min";
import {  useParams } from 'react-router-dom';
import FolderCopyIcon from "@mui/icons-material/FolderCopy";
import AOS from 'aos';
import 'aos/dist/aos.css';
import CircularProgress from '@mui/material/CircularProgress';
const Accordion = styled((props) => (
  <MuiAccordion disableGutters elevation={0} square {...props} />
))(({ theme }) => ({
  border: `1px solid ${theme.palette.divider}`,
  '&:not(:last-child)': {
    borderBottom: 0,
  },
  '&::before': {
    display: 'none',
  },
}));

const AccordionSummary = styled((props) => (
  <MuiAccordionSummary
    expandIcon={<ArrowForwardIosSharpIcon sx={{ fontSize: '0.9rem' }} />}
    {...props}
  />
))(({ theme }) => ({
  backgroundColor:
    theme.palette.mode === 'dark'
      ? 'rgba(255, 255, 255, .05)'
      : 'rgba(0, 0, 0, .03)',
  flexDirection: 'row-reverse',
  '& .MuiAccordionSummary-expandIconWrapper.Mui-expanded': {
    transform: 'rotate(90deg)',
  },
  '& .MuiAccordionSummary-content': {
    marginLeft: theme.spacing(1),
  },
}));

const AccordionDetails = styled(MuiAccordionDetails)(({ theme }) => ({
  padding: theme.spacing(2),
  borderTop: '1px solid rgba(0, 0, 0, .125)',
}));

export default function Question() {
  let { subcatagoryID } = useParams();
  let [AccordionData, SetAccordionData] = useState([]);
  let [Search, SetSearch] = useState("");
  let [open, setOpen] = React.useState(false);
  let [Loading,SetLoading]=useState(true)



  

  // const theme = useTheme();
  // const fullScreen = useMediaQuery(theme.breakpoints.down("md"));
const handleClickOpen = () => {
  setOpen(true);
}
let HISTORY = useHistory();
const handleClickOpenModal =  (questions) => {
  console.log(questions._id);
  // HISTORY.push(`/Question/${questions._id}`);
 
};
let QustionAnswer=()=>{

  axios.get("http://localhost:5500/questions/", {
      headers: {
          Authorization: localStorage.getItem("ADMINLOGIN")
      }
  })
      .then((res) => {
        if(subcatagoryID){
          console.log("Subcategory API response:", res.data);
          const filteredQuestion = res.data.data.filter(item => {
            return (subcatagoryID === item.subcatagoryID._id) && (item.questions.toLowerCase().includes(Search.toLowerCase()));
          });
          SetAccordionData(filteredQuestion);
        }
        else{
          SetAccordionData(res.data.data)
          SetLoading(false)
        }
      })
      .catch((err) => {
          console.log(err);
          SetLoading(false)
      })
}
useEffect(() => {
    
    QustionAnswer();
    AOS.init();
  }, [subcatagoryID])

  const [expanded, setExpanded] = React.useState(null);

  const handleChange = (panel) => (event, isExpanded) => {
    setExpanded(isExpanded ? panel : false);
  };

  return (
    <Box sx={{marginBottom:"50px"}}>
      {/* {
        Loading?(
          <Box sx={{ display: 'flex',alignItems:'center',justifyContent:'center',height:'100vh' }}>
      <CircularProgress />
    </Box>
        ):( */}
          <Container maxWidth='md'>
          <Box sx={{ display: "flex", justifyContent: "center", alignItems: "center" , margin:"50px 0px"}} data-aos="fade-up">
            <AutoStoriesIcon sx={{ fontSize: "50px", mr: 2 }} />
            <Typography variant="h4" sx={{color:'#1976D2'}}> Interview Frequently Asked Questions </Typography>
            <AutoStoriesIcon sx={{ fontSize: "50px", mr: 2 }} />
          </Box>
          <Box  sx={{ display: "flex", alignItems: "center",justifyContent:'center' }} data-aos="fade-up">
                    <SearchTwoTone
                      sx={{
                        marginRight: "20px",
                        border: "2px solid",
                        color: "#1976D2",
                        p: 1,
                        height: "40px",
                        width: "40px",
                        borderRadius: "5px",
                      }}
                    />
                    <TextField
                      fullWidth
                      label="SEARCH...."
                      sx={{ width: "400px" }}
                      onChange={(e) => SetSearch(e.target.value)}
                    />
                    {/* <Button variant="contained" color="primary" sx={{ height: "55px" }}>SEARCH </Button> */}
                    <Button
                        variant="contained"
                        onClick={handleClickOpen}
                        sx={{ marginLeft: "10px",background:' #1976D2' }}
                      >
                        <FolderCopyIcon sx={{ marginRight: "10px" }} /> Sreach 
                        CATEGORIES
                      </Button>
                  </Box>
                 
          {
             AccordionData.filter((items) => {
              if (items.subcatagoryID.status ==="on" && items.subcatagoryID.catagoryID.status ==="on" ) {
                  return Search === "" || items.questions.toLowerCase().includes(Search.toLowerCase())
              }
              return false
          })
          .map((el, index) => (
            <Accordion
              key={index}
              expanded={expanded === index}
              onChange={handleChange(index)}
             sx={{marginBottom:'20px',marginTop:'20px'}}
             
             onClick={() => handleClickOpenModal(el)}
            >
              <AccordionSummary aria-controls={`panel${index}d-content`} id={`panel${index}d-header`}>
                <Typography sx={{ textTransform: "uppercase", textAlign: "justify",color:'#8F2727' }}> {index + 1} . {el.questions}</Typography>
              </AccordionSummary>
              <AccordionDetails>
                <Typography sx={{ textTransform: "uppercase", textAlign: "justify",color:'grey',marginBottom:'10px' }}>{el.answer}</Typography>
                <Typography sx={{ textTransform: "uppercase", textAlign: "justify",color:'grey',marginBottom:'10px' }}>{el.Description}</Typography>
                <Typography sx={{ textTransform: "uppercase", textAlign: "justify",color:'grey',marginBottom:'10px' }}>{el.metaTitle}</Typography>
                <Typography sx={{ textTransform: "uppercase", textAlign: "justify",color:'grey',marginBottom:'10px' }}>{el.slug}</Typography>
              </AccordionDetails>
             
            </Accordion>
          ))}
          </Container>
        {/* )
      }
       */}
    </Box>
  );
}


