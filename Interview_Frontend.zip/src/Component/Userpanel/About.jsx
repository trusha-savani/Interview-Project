import React from 'react'
import Box from '@mui/material/Box';
import Container from '@mui/material/Container';
import Typography from '@mui/material/Typography';
import Grid from '@mui/material/Grid';
import CheckCircleOutlineRoundedIcon from '@mui/icons-material/CheckCircleOutlineRounded';
import Button from '@mui/material/Button';
import ArrowForwardIcon from '@mui/icons-material/ArrowForward';
import AOS from 'aos';
import 'aos/dist/aos.css';
import { useEffect } from 'react';
function About() {
  useEffect(()=>{
    AOS.init();
  })
  return (
  <Box>
      <Container >
        <Box  data-aos="fade-up" sx={{display:'flex',justifyContent:'space-between'}}>
          <Box>
          <Box className="section-title" sx={{padding:'10px'}} >
     
     <Typography className='about-1'  variant="h4" sx={{textAlign:'center',marginTop:"50px",textTransform:'uppercase',fontWeight:'700'}}>about us</Typography>
 
     </Box>
     <Box sx={{display:'flex',justifyContent:'center',marginTop:'10px',color:'gray'}}>
      <p >Necessitatibus eius consequatur ex aliquid fuga eum quidem sint consectetur velit</p>
     </Box>
     <Box  >

          </Box>
      
       <Grid container spacing={2} sx={{marginTop:"20px"}} data-aos="fade-right">
<Grid item xs={12} xl={6} md={6} sm={{width:"100%"}} data-aos="fade-right" >
        
  <Box sx={{paddingx:'5px'}} >
    <Box>
      <Typography variant='h4' sx={{fontWeight:'700'}}>Every day we discuss the most interesting thing</Typography>
    </Box>
    <Box sx={{fontStyle:'italic',color:'grey',marginTop:'10px'}} md={{fontSize:'10px'}}>
      <Typography>The most difficult part of the interview is the revoicing test. During this test, you will hear audio and have to repeat what you hear as the audio continues.</Typography>
    </Box>
    <Box sx={{display:'flex',alignItems:'center',marginTop:'10px'}}>
    <CheckCircleOutlineRoundedIcon  sx={{color:'#1976D2'}}/>
    <Typography sx={{marginLeft:'5px',color:'#444444'}}> A career is a series of ups and downs, of comebacks.</Typography>
    </Box>
    <Box sx={{display:'flex',alignItems:'center',marginTop:'10px'}}>
    <CheckCircleOutlineRoundedIcon  sx={{color:'#1976D2'}}/>
    <Typography sx={{marginLeft:'5px',color:'#444444'}}>  Duis aute irure dolor in reprehenderit in voluptate velit.</Typography>
    </Box>
    <Box sx={{display:'flex',alignItems:'center',marginTop:'10px'}}>
    <CheckCircleOutlineRoundedIcon  sx={{color:'#1976D2'}}/>
    <Typography sx={{marginLeft:'5px',color:'#444444'}}>  
All your hard work will pay off. My best wishes are with you.
</Typography>
    

    </Box>
    <Box sx={{marginTop:'20px',borderRadius:'none'}} justifyContent={{md:'center'}}>
    <Button variant="contained"  sx={{backgroundColor:'#1976D2'}} endIcon={<ArrowForwardIcon />}>

READ MORE
</Button>
    </Box>
  </Box>
</Grid>
<Grid item xs={12} xl={6} md={6} sm={{width:'100%'}} >
  <Box  data-aos="fade-left" sx={{display:'flex',justifyContent:'end'}}>
    <img src='https://bootstrapmade.com/demo/templates/Day/assets/img/about.jpg' style={{width:'100%',height:'400px'}} md={{width:'100%'}} xl={{width:'100%'}} alt='name' />
  </Box>
</Grid>


</Grid>
       </Box>
       </Box>
      </Container>
    
  </Box>
    
  )
}

export default About
