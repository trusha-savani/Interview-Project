import React from 'react'
import AppBar from '@mui/material/AppBar';
import Box from '@mui/material/Box';
import Toolbar from '@mui/material/Toolbar';
import Typography from '@mui/material/Typography';
import Button from '@mui/material/Button';
import WidgetsIcon from '@mui/icons-material/Widgets';
import { Link } from 'react-router-dom/cjs/react-router-dom.min';


function Usernavbar() {
   
  
  
  return (

      <Box sx={{ flexGrow: 1,position:"sticky",top:'0',zIndex:'2'}}>
            <AppBar  sx={{  color: '#fff',backgroundColor:'white',display:'flex',position:'relative ',top:'0px' }}>
                <Toolbar sx={{ display: "flex", justifyContent: "space-between" }}>
                    <Box sx={{ display: "flex" }} >
                        <Link to="/">
                            <WidgetsIcon sx={{ fontSize: '30px', marginRight: "5px", color: '#1976D2' }} />
                        </Link>
                        <Typography variant="h5" component="div" sx={{ flexGrow: 1,textTransform:'uppercase' }} display={{ lg: "block", md: "block", xs: "flex" }} >
                            <Link to="/" style={{ textDecoration: "none", color: '#1976D2', }}> interview </Link>
                            
                        </Typography>
                    </Box>
                    <Box display={{xl:'flex',md:'flex',sm:'flex',xs:'none'}} >
                   <Link to="/"> <Button sx={{color:"#1976D2"}}>Home</Button></Link>
                   <Link to="/about"> <Button sx={{color:"#1976D2"}}>About</Button></Link>
                   
                        <Link to="/usercategory"><Button  sx={{ fontSize: "14px",color:"#1976D2" }}> CATEGORY </Button></Link>
                       
                        <Link to="/subcategory"><Button color="error" sx={{ fontSize: "14px",color:"#1976D2" }}> SUB CATEGORIES </Button></Link>
                        <Link to="/Question"><Button color="error" sx={{ fontSize: "14px",color:"#1976D2" }}> QUESTIONS </Button>  </Link>
                        {/* <Link to="/footer"><Button color="error" sx={{ fontSize: "14px",color:"#8F2727" }}> Contect </Button>  </Link> */}
                    </Box>
                </Toolbar>
            </AppBar>
        </Box>
  
  )
}

export default Usernavbar
