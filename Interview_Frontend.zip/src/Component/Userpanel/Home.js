import React from 'react'
import Slider from "react-slick";
import Box from '@mui/material/Box';
import Typography from '@mui/material/Typography';
import Button from '@mui/material/Button';
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";
import AOS from 'aos';
import 'aos/dist/aos.css';
import { Link } from 'react-router-dom/cjs/react-router-dom.min';
import { useEffect } from 'react';
var settings = {
    dots: false,
    infinite: true,
    speed: 700,
    slidesToShow: 1,
    slidesToScroll: 1,
  };

  
function Home() {
  useEffect(()=>{
    AOS.init();
  },[])
  return (
    <div>
         <Box>
    <div className="slider-container">
      <Slider {...settings}>
        <div className='name'>
          <img src="https://img.freepik.com/premium-photo/female-friends-using-digital-tablet-home_1048944-4153385.jpg?w=740" alt="" />
          <div className='abc ' data-aos="fade-up" >
            {/* <Box sx={{backgroundColor:'black ',padding:'10px',opacity:'0.7',color:'white'}} >
              <Typography sx={{fontSize:'30px'}}>Welcome To Company</Typography>
              <Box>
              <Typography style={{padding:'5px'}}>
              An interview is an essential part of getting a new job and many professionals find this step challenging. To overcome this challenge, candidates can seek ways to ease their anxiety and boost their confidence. Contemplating words of encouragement from your peers and inspirational quotes can help you realise your potential and feel good about meeting with a hiring manager. 
              </Typography>
            </Box>
            <Box sx={{display:'flex',justifyContent:'center'}}>

            <Button variant='outlined' color="inherit" sx={{border:'2px solid #1976D2'}} >Read More</Button>
            </Box>
            </Box> */}
           </div>
          {/* <div className='line'>
            <img src='https://metrobank-sobujhcs-projects.vercel.app/assets/images/shape/shape-1.png' alt='name' />
            
          </div>  */}

        </div>
       
        <div className='name'>
          <img src="https://img.freepik.com/free-photo/employees-meeting-room-office_114579-2799.jpg?t=st=1714841739~exp=1714845339~hmac=264b9ac46c4969ebf9954fba873289fa8c3c93baa9544b72f7077c3b93e9e229&w=996" alt='name' />
          <div className='abc ' data-aos="fade-up">
            {/* <Box sx={{backgroundColor:'black ',padding:'10px',opacity:'0.7',color:'white'}}>
              <Typography sx={{fontSize:'30px'}}>Presentation in project interview</Typography>
              <Box>
              <Typography style={{padding:'5px'}}>
              An interview is an essential part of getting a new job and many professionals find this step challenging. To overcome this challenge, candidates can seek ways to ease their anxiety and boost their confidence. Contemplating words of encouragement from your peers and inspirational quotes can help you realise your potential and feel good about meeting with a hiring manager. 
              </Typography>
            </Box>
            <Box sx={{display:'flex',justifyContent:'center'}}>

            <Button variant='outlined' color="inherit" sx={{border:'2px solid  #1976D2'}} >Read More</Button>
            </Box>
            </Box> */}
           </div>
          </div>
        <div className='name'>
          <img src="https://img.freepik.com/free-photo/creative-people-working-office_23-2147656715.jpg?t=st=1714841944~exp=1714845544~hmac=0b146588d7f2e106864f79f80f396c1a9003f14cf2839fb37f59fc629ba6d550&w=740" alt='name' />
          <div className='abc ' data-aos="fade-up">
            {/* <Box sx={{backgroundColor:'black ',padding:'10px',opacity:'0.7',color:'white'}}>
              <Typography sx={{fontSize:'30px'}}>Office Grup Metting</Typography>
              <Box>
              <Typography style={{padding:'5px'}}>
              An interview is an essential part of getting a new job and many professionals find this step challenging. To overcome this challenge, candidates can seek ways to ease their anxiety and boost their confidence. Contemplating words of encouragement from your peers and inspirational quotes can help you realise your potential and feel good about meeting with a hiring manager. 
              </Typography>
            </Box>
            <Box sx={{display:'flex',justifyContent:'center'}}>

            <Link to='/Question'><Button variant='outlined' color="inherit" sx={{border:'2px solid  #1976D2'}} >Read More</Button></Link>
            </Box>
            </Box> */}
           
       
          </div>
        </div>
      </Slider>
    </div>
    </Box>
    </div>
  )
}

export default Home
