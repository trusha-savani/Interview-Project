import React from 'react'
import Grid from '@mui/material/Grid';
import Box from '@mui/material/Box';
import { Container, Divider, Stack, Typography } from '@mui/material';
import FacebookIcon from '@mui/icons-material/Facebook';
import TwitterIcon from '@mui/icons-material/Twitter';
import GoogleIcon from '@mui/icons-material/Google';
import InstagramIcon from '@mui/icons-material/Instagram';
import LinkedInIcon from '@mui/icons-material/LinkedIn';
import GitHubIcon from '@mui/icons-material/GitHub';
import WidgetsIcon from '@mui/icons-material/Widgets';
import HomeIcon from '@mui/icons-material/Home';
import EmailIcon from '@mui/icons-material/Email';
import LocalPhoneIcon from '@mui/icons-material/LocalPhone';
function Footer() {
  return (
    <Box>
        <Box sx={{marginTop:'60px',backgroundColor:'black'}}>
      <Container>
      <Grid container spacing={2} sx={{display:'flex',alignItems:'center'}}>
  <Grid item xl={6} md={6} sm={6} xs={12} >
    <Box sx={{marginTop:'10px',display:'flex',alignItems:'center',marginBottom:'20px'}} xs={{justifyContent:'center'}}>
        <Typography sx={{color:'#1976D2',fontWeight:'700'}} >Get connected with us on social networks:</Typography>
    </Box>
  </Grid>
  <Grid item xl={6} md={6} sm={6} xs={12} spacing={3}>
    <Box sx={{margin:'0px 10px',marginBottom:'20px'}}>
        <Stack spacing={3}  direction="row" alignItems='center' xs={{justifyContent:'center'}} sx={{justifyContent:'end',color:'#1976D2'}}>
        <FacebookIcon />
     <TwitterIcon />
     <GoogleIcon />
     <InstagramIcon />
     <LinkedInIcon />
     <GitHubIcon />

        </Stack>
     
    </Box>
  </Grid>

</Grid>
      </Container>
    </Box>
    <Divider sx={{color:'grey',}}/>
    <Box sx={{backgroundColor:'#151515',marginTop:'15px'}}>
    <Container>
    <Grid container spacing={2}>
  <Grid item xs={12} xl={3} md={3} sm={6} >
    <Box sx={{padding:'0px 20px 0px 5px'}}>
    <Box sx={{display:'flex',alignItems:'center'}} >
        <WidgetsIcon sx={{fontSize:'18px',color:'#1976D2'}} />
        <Typography sx={{fontSize:'16px',margin:'0px 5px',fontWeight:'700',color:'white'}}>COMPANY NAME</Typography>
    </Box>
    <Box sx={{marginTop:'15px',fontSize:'12px',marginBottom:'50px'}}>
        <Typography sx={{fontSize:'15px',color:'#fff'}}>Here you can use rows and columns to organize your footer content. Lorem ipsum dolor sit amet, consectetur adipisicing elit.</Typography>
    </Box>
    </Box>
   
  </Grid>
  <Grid item xs={12} xl={3} md={3} sm={6}>
    <Box>
        <Box>
            <Typography sx={{fontSize:'16px',margin:'0px 5px',fontWeight:'700',color:'white'}}>Developer</Typography>
        </Box>
        <Box sx={{marginTop:'15px',color:'white'}}>
        <Typography sx={{fontSize:'15px',margin:'5px 0px'}}>Frontend  </Typography>
        <Typography sx={{fontSize:'15px',margin:'5px 0px'}}>Backend </Typography>
        <Typography sx={{fontSize:'15px',margin:'5px 0px'}}>Designer  </Typography>
        <Typography sx={{fontSize:'15px',margin:'5px 0px'}}>FullStack</Typography>
    </Box>
    </Box>
  </Grid>
  <Grid item xs={12} xl={3} md={3} sm={6}>
    <Box>
         <Box>
            <Typography sx={{color:'white',fontWeight:'700'}}>SKILL</Typography>
        </Box>
        <Box sx={{marginTop:'15px',color:'white'}}>
        <Typography sx={{fontSize:'15px'}}>HTML  </Typography>
        <Typography sx={{fontSize:'15px'}}>CSS </Typography>
        <Typography sx={{fontSize:'15px'}}>C & C++  </Typography>
        <Typography sx={{fontSize:'15px'}}>JAVASCRIPT</Typography>
        <Typography sx={{fontSize:'15px'}}>REACT JS</Typography>
    </Box>
        
    </Box>
  </Grid>
  <Grid item xs={12} xl={3} md={3} sm={6}>
    <Box >
    
    <Box >
            <Typography sx={{fontWeight:'700',color:'white'}}>CONTACT</Typography>
    </Box>
    <Stack direction='row' spacing={1} sx={{marginTop:'10px '}}>
        <HomeIcon sx={{color :'#1976D2'}} />
        <Typography sx={{color:'#fff'}}>Adajan,ny 364000,SURAT</Typography>
      </Stack>
      <Stack direction='row' spacing={1} sx={{marginTop:'10px '}}>
        <EmailIcon sx={{color :'#1976D2'}} />
        <Typography sx={{color:'#fff'}}>trusha.goti9455@gmail.com</Typography>
      </Stack>
      <Stack direction='row' spacing={1} sx={{marginTop:'10px '}}>
        <LocalPhoneIcon sx={{color :'#1976D2'}} />
        <Typography sx={{color:'#fff'}}>01 942 503 037</Typography>
      </Stack>
    </Box>
  </Grid>
</Grid>
    </Container>
    </Box>
    <Box sx={{backgroundColor:'black',height:'70px'}}>
      <Stack direction='row' sx={{justifyContent:'center',alignItems:'center'}}>
      <Typography sx={{marginTop:'25px',color:'white'}}>© Copyright  </Typography>
      <Typography sx={{marginTop:'25px',fontWeight:'700',marginLeft:'5px',color:'#1976D2'}}> INTERVIEW. </Typography>
      </Stack>
    </Box>
    </Box>
    
  )
}

export default Footer
