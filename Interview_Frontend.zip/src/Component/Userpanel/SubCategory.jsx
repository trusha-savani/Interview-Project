import React from 'react'
import { Box } from '@mui/material';
import Container from '@mui/material/Container';
import AutoStoriesIcon from '@mui/icons-material/AutoStories';
import Typography from '@mui/material/Typography';
import { useState } from 'react';
import axios from "axios";
import { useEffect } from 'react';
import Card from '@mui/material/Card';
import CardContent from '@mui/material/CardContent';
import Grid from '@mui/material/Grid';
import { SearchTwoTone } from "@mui/icons-material";
import TextField from "@mui/material/TextField";
import Button from "@mui/material/Button";
import { useTheme } from "@mui/material/styles";
import useMediaQuery from "@mui/material/useMediaQuery";
import FolderCopyIcon from "@mui/icons-material/FolderCopy";
import AOS from 'aos';
import 'aos/dist/aos.css';
import TopicIcon from '@mui/icons-material/Topic';
import { useHistory } from "react-router-dom/cjs/react-router-dom.min";
import {  useParams } from 'react-router-dom';
import CircularProgress from '@mui/material/CircularProgress';
import CardMedia from '@mui/material/CardMedia';
import Divider from '@mui/material/Divider';

const SubCategory = () => {
  let { categoryId } = useParams();
    let [subcategoryData,SetSubcategoryData]=useState([])
    let [Search, SetSearch] = useState("");
    let [Loading,SetLoading]=useState(true)
    // let [Category,SetCategory]=useState('')
    let HISTORY = useHistory();

    const handleClickOpenModal =  (subCatagoryname) => {
      console.log(subCatagoryname._id);
      // HISTORY.push(`?:${subCatagoryname._id}`);
      HISTORY.push(`/Question/${subCatagoryname._id}`);

    };
  

    const [open, setOpen] = React.useState(false);
  const theme = useTheme();
  const fullScreen = useMediaQuery(theme.breakpoints.down("md"));
const handleClickOpen = () => {
  setOpen(true);
};

let Sub_Category = () => {
  axios.get("http://localhost:5500/subcatagory/", {
      headers: {
          Authorization: localStorage.getItem("ADMINLOGIN")
      }
  })
      .then((res) => {
        if(categoryId){
          console.log("Subcategory API response:", res.data);
          const filteredSubcategories = res.data.data.filter(item => {
            return (categoryId === item.catagoryID._id) && (item.status === "on") && (item.subCatagoryname.toLowerCase().includes(Search.toLowerCase()));
          });
          SetSubcategoryData(filteredSubcategories);
          
         }
        else{
          SetSubcategoryData(res.data.data)
          SetLoading(false)
        }
         })
      .catch((err) => {
          console.log("Error fetching subcategories:", err);
          SetLoading(false)
      });
};
useEffect(() => {
      AOS.init();
      Sub_Category()
     
      }, [categoryId])
    
    
  return (
    <div>
          <Box sx={{marginBottom:"50px"}}>
            {/* {
              Loading?(
                <Box sx={{ display: 'flex',alignItems:'center',justifyContent:'center',height:'100vh' }}>
                <CircularProgress />
              </Box>
              ):( */}
                <Container>
                <Box sx={{ display: "flex", justifyContent: "center", alignItems: "center" , margin:"50px 0px"}} data-aos="fade-up">
                  <AutoStoriesIcon sx={{ fontSize: "50px", mr: 2 }} />
                  <Typography variant="h4" color="#1976D2">Sub Category </Typography>
                  <AutoStoriesIcon sx={{ fontSize: "50px", mr: 2,marginLeft:'20px' }} />
                </Box>
                <Box  sx={{ display: "flex", alignItems: "center",justifyContent:'center' }} data-aos="fade-up">
                          <SearchTwoTone
                            sx={{
                              marginRight: "20px",
                              border: "2px solid",
                              color: "#1976D2",
                              p: 1,
                              height: "35px",
                              width: "35px",
                              borderRadius: "5px",
                            }}
                          />
                          <TextField
                            fullWidth
                            label="SEARCH...."
                            sx={{ width: "400px" }}
                            onChange={(e) => SetSearch(e.target.value)}
                          />
                          {/*<Button variant="contained" color="primary" sx={{ height: "55px" }}>SEARCH </Button> */}
                          <Button
                              variant="contained"
                              onClick={handleClickOpen}
                              sx={{ marginLeft: "10px",background:'#1976D2' }}
                            >
                              <FolderCopyIcon sx={{ marginRight: "10px" }} /> Sreach 
                              CATEGORIES
                            </Button>
                        </Box>
                       
                <Grid container spacing={2} sx={{marginTop:'20px'}}>
                {
            //     subcategoryData.filter((items) => {
            //     if (Search === "") {
            //         return items
            //     }
            //     else if (items.subCatagoryname .toLowerCase().includes(Search.toLowerCase())) {
            //         return items
            //     }
            // })
            subcategoryData
            .filter((items)=>{
              if(items.status === "on" && items.catagoryID.status ==="on"){
                return items == ""|| items.subCatagoryname.toLowerCase().includes(Search.toLowerCase())
              }
              return false;
              
            })
                  .map((el,index)=>
                  (
                    

            <Grid item xl={4} md={4} sm={6} xs={12} data-aos="fade-up">
            <Card sx={{ minWidth: 275,background:'#fff',boxShadow:'10px 0px 10px #D5D8DC '}} key={index}  onClick={() => handleClickOpenModal(el)}>
              {/* <Box>
              <img src={`http://localhost:5500/images/subcategory/${el.subCategoryImage}`} alt={el.alternamtiveImage} style={{width:'100%',height:'200px'}} />

              </Box> */}
              <CardMedia
                     sx={{ height: 200 }}
                     component="img"
                     image={`http://localhost:5500/images/subcategory/${el.subCategoryImage}`}
                     title="green iguana"
                     alt="{el.alternamtiveImage} "
                     />
          <CardContent>
          <Box sx={{display:'flex',justifyContent:'start',alignItems:'center' }}>
            <FolderCopyIcon sx={{color:'#1976D2',marginRight:'10px'}} />
            <Typography variant="h5"   component="div" sx={{textAlign:'start',color:'#1976D2'}}  >{el.subCatagoryname}</Typography>
          </Box>
          <Typography sx={{color:'black',textAlign:'start'}} variant='h6'>({el.catagoryID.catagoryName})</Typography>
          <Divider sx={{backgroundColor:'black',mt:'5px'}} />
         

          <Typography sx={{color:'grey',textAlign:'start',marginTop:'4px',fontFamily:'sans-serif'}} variant='h6'>{el.Description}</Typography>
      
               
                            
                          </CardContent>
                        
                        </Card>
            </Grid>
                
          ))
          }
          </Grid>
      </Container>
              {/* )
            } */}
      
    </Box>
    
    </div>
  )
}

export default SubCategory
